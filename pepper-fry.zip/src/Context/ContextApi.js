import React from 'react'
 const Contexts =React.createContext()
 export default Contexts;