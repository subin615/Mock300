import './Products.scss'
import React, { useContext } from 'react'
import Contexts from '../../Context/ContextApi';

function Products(props) {

  const {products} =useContext(Contexts);
  console.log(products);
  return (
    <div>
        <h1>Products</h1>
        <h3>Mohan kumar</h3>
        <button>Add to</button>
    </div>
  )
}

export default Products;