import './CartItem.scss'
import React, { useContext, useState } from 'react'
import { Paper } from '@mui/material';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import Contexts from '../../Context/ContextApi';

function CartItem(props) {
 const { image, price, name,count , id}=props.value;
  const { products, cart, setCart } = useContext(Contexts);

const {i}=props.key;
 let num;
 const [count,setCount]=useState();
  console.log(image,price,name);
 const increment =(id)=>{
  //  const increase;
    products[id].count=num+1;

  // count++
 }
 const decrement =()=>{
  count++;

 }

  return (
    <div  className='card paper' >
      <div className="row cartitem">
        {/* <div className="thu"> */}
         <div className= "col-4 p-0">
          <img
          height ="170px"
          width="275px"
            // object-fit="contain"
            src={image}
          />
          </div>
        {/* </div>
        <div> */}
         <div className="col-6 p-2">
          <h3>{name}</h3>
          <h2>${price}</h2></div>
        {/* </div>
        <div> */}
          <div className="col-2 m-auto">
         <div className="row counter"> 
         <button onClick={decrement}>-</button>
         <p>{count}</p>
         <button onClick={()=>{increment(i)}}> + </button>
         </div>
          <DeleteForeverIcon sx={{fontSize:"xxx-large",margin:"25px 45px"}}/>
          
          </div>
        {/* </div> */}
      </div>
    </div >
  );
}

export default CartItem 